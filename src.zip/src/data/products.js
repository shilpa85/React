const products = [
  {
    id: "1",
	productName: "Lorem Ipsum dolor de amet",
    price: 198.99,
    currency: "dollar",
	quantity:1
  },
  {
	id: "2",
	productName: "Lorem Ipsum dolor de amet",
    price: 198.99,
    currency: "dollar",
	quantity:1
  }
];

export default products;
