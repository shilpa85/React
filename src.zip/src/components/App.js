import React from 'react';
import Cart from './Cart.js';

class App extends React.Component {

	render(){
	  return (
		<>
			<Cart />
		</>
	  );
	}
}

export default App;
