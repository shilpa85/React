import React, { useState, useEffect } from 'react';
import ProductItem from './ProductItem.js';
import './Cart.scss';

import productList from "../data/products";

const Cart = (props) => {

	const [products, setProducts] = useState([])

	useEffect(()=>{
		setProducts(productList);
	}, [])

		
 		return (
				<div>
					{products.map(item =>
						<ProductItem product={item} key={item.id} />
					)}
					
				</div>)

	

}
export default Cart;

