import React, {useState, useEffect} from 'react';

const ProductItem = props => {
	
	
	const [quantity, setQuantity] = useState(1)

	useEffect(()=>{
		//setQuantity(props.product.quantity);
	}, [])

	const handleInputChange = (e) => {
		console.log(e.target.value)
		setQuantity(e.target.value)
	}

	const handleDelete = (e) => {
		console.log(e)
		//setQuantity(e.target.value)
	}
		
	return (
		<div>	
		<h4>{props.product.productName} {props.product.id}</h4>
		<div>{props.product.quantity}
		${props.product.price}</div>
		<input type="number" value={quantity} min="1" max="5" onChange={handleInputChange} />

		<button><img src="../assets/delete-icon.png" alt="delete" onClick={handleDelete} /></button>
		</div>
	)




}

export default ProductItem;

